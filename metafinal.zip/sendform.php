<?php
header("HTTP/1.1 200 OK");
header('Content-type: text/html; charset=utf-8');
// отсекаем лишние запросы
if ($_SERVER["REQUEST_METHOD"] != "POST") {
	echo "Hello world!";
	exit();
}
// формируем запись в таблицу google (изменить)
$url = "https://docs.google.com/forms/d/e/1FAIpQLSeA8uVG-gKz5FHbAwhBupOf6vJ6DEXzTTg9ZKPT-sFkJ8mlWw/formResponse";
// ссылка для переадресации (изменить)
$link = "/";
// массив данных (изменить entry, draft и fbzx)
$post_data = array(
	"entry.1090484450" => $_POST['first_name'] . ' ' . $_POST['last_name'],
	"entry.2092023907" => $_POST['email'],
	"entry.91746849" => $_POST['phone_number'],
	"entry.101425649" => $_POST['country'],
	"fvv" => "1",
	"partialResponse" => "[null,null,&quot;-3355165362008897168&quot;]",
	"pageHistory" => "0",
	"fbzx" => "-3355165362008897168"
);
// Далее не трогать
// с помощью CURL заносим данные в таблицу google
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
// указываем, что у нас POST запрос
curl_setopt($ch, CURLOPT_POST, 1);
// добавляем переменные
curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
//заполняем таблицу google
$output = curl_exec($ch);
curl_close($ch);
//перенаправляем браузер пользователя на скачивание оффера по нашей ссылке
header('Location: ' . $link);
