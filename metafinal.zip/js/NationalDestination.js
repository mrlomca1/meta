function getCountryByDialCode(dialCode) {
    const countryCodes = {
        '+1': 'USA and Canada',
        '+44': 'United Kingdom',
        '+33': 'France',
        '+49': 'Germany',
        '+7': 'Russia and Kazakhstan',
        '+81': 'Japan',
        '+86': 'China',
        '+91': 'India',
        '+61': 'Australia',
        '+55': 'Brazil',
        // Добавьте остальные коды и страны по необходимости
    };

    return countryCodes[dialCode] || 'Unknown Country';
}